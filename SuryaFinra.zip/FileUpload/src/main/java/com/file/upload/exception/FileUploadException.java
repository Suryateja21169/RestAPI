/**
 * 
 */
package com.file.upload.exception;

/**
 * @author surya.putta
 *
 */
public class FileUploadException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String getMessage() {

		return "File does not exist.";
	}
}
